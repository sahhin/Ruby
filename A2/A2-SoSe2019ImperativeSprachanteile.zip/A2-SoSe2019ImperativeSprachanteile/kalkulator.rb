class Kalkulator

# TODO
def sum_kubik(n)

end
# TODO
def reihe_sin(x,n)

end
# TODO
def reihe_sin_opt(x,n)

end
# TODO
def n_fuer_fehler_kleiner(x, eps)

end
# TODO
def fak(upper,lower=1)

end
# TODO
def binom(n,k)

end

end

