require "./kalkulator_dialog"
KalkulatorDialog.new("bye").starten()
