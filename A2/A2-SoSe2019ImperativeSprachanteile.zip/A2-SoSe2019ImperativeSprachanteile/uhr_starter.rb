require "./Uhr"
Uhr.new().starten(10)

Uhr.new(27,74,98).starten(10)