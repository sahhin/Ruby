require './datum'
require './dauer'
# Die Klasse repräsentiert die Termine des Terminkalenders
# Termine setzen sich aus Beschreibung, Datum und Dauer zusammen
#
class Termin
  attr_reader :datum, :beschreibung, :dauer
  def initialize(beschreibung,datum, dauer)
    @beschreibung = beschreibung
    @datum = datum
    @dauer = dauer
  end

  # TODO

  def to_s()
    "#{datum} #{beschreibung} (#{dauer.minuten()} Min)"
  end
end