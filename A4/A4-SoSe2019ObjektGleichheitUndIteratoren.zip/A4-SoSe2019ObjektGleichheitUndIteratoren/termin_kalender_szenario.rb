require "./termin_kalender"
require './termin'
require './tag'
require './monat'
require './dauer'

tk = TerminKalender.new("Von Birgit")

termin1 = Termin.new("PM1/PT1", Datum.new(17, 4, 2019, 8, 15), Dauer.new(180))
#puts termin1
termin2 = Termin.new("PM1/PT1", Datum.new(18, 4, 2019, 11, 30), Dauer.new(120))
termin3 = Termin.new("Vorbereitung", Datum.new(18, 4, 2019, 11, 15), Dauer.new(15))
termin4 = Termin.new("Nachbereitung", Datum.new(19, 4, 2019, 13, 25), Dauer.new(180))
tk << termin1
tk << termin2
tk << termin3
tk << termin4

puts "4.3.a Termine ausgeben"

puts "4.3.b Terminkalender nach Datum absteigend sortieren"

tag = Tag.new(19,4,2019)

puts "4.3.c Termine vor Tag #{tag}"

tag2 =Tag.new(18,4,2019)
puts "4.3.d Termine am Tag #{tag2}"

puts "4.3.e Gruppieren nach Tag"
# Auf das Ergebnis ein map(){|key,val| "#{key} => [#{val.join(", ")}]"} anwenden um die gezeigte Ausgabe zur erhalten

puts "4.3.f Gruppieren nach Monat"

puts "4.3.g Frühester Termin"


puts "4.3.h Längster Termin"

puts "4.3.i Prüfen auf Enthaltensein"
termin11 = Termin.new("PM1/PT1", Datum.new(17, 4, 2019, 8, 15), Dauer.new(180))
puts "Termin #{termin11} enthalten in Kalender:"


puts "4.3.j Gruppieren nach Dauer:"

puts "4.3.k Abbilden auf Dauer und Datum:"

beschreibung = "PM1/PT1"
puts "4.3.l Gesamtdauer von Terminen #{beschreibung}"

monat = Monat.new(4,2019)
puts "4.3.m Sind alle Termine im Monat #{monat} mindestens 30 Minuten lang:"

puts "4.3.n Ist ein Termin im Monat #{monat} mindestens 30 Minuten lang:"
