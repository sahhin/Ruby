require_relative "./Knoten"

class VerketteListe

  def initialize()
    @start = nil
  end

  def empty?()
    #TODO
  end

  def <<(inhalt)
    #TODO
  end

  def each(&block)
    #TODO
  end

  # Gegeben
  def to_s()
    "["+ to_a().join(",") +"]"
  end
end

