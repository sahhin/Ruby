require "./Turtle"
class GosperKurve

  def zeichnen(n,x,y,kl)
    @turtle = Turtle.new(x,y)
    _zeichnen(n,kl)
  end

  def loeschen()
    @turtle.loeschen()
  end

  def _zeichnen(n,kl)
    #TODO
  end
end