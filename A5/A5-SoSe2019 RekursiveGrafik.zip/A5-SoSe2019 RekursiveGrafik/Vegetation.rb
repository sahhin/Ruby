require "tk"
require "./Turtle"
require "./Point"

class Vegetation
  BAUM = 1
  RANKE = 2
  BAUM_LAENGE = 64
  RANKE_LAENGE = 32
  BAUM_BREITE = 2
  RANKE_BREITE = BAUM_BREITE
  BAUM_WINKEL = 22
  RANKE_WINKEL = 28

  C0 = "#808000" # Olive
  C1 = "#3CB371" # MediumSeaGreen
  C2 = "#66CDAA" # MediumAquamarine
  C3 = "#90EE90" # LightGreen

  def zeichnen(typ,wiederholungen,x,y)
    # Turtle schaut nach Norden
    @turtle = Turtle.new(x,y,90)
    case typ
    when BAUM
      baum(wiederholungen, BAUM_WINKEL,BAUM_LAENGE/2**(wiederholungen-1), BAUM_BREITE)
    when RANKE
      ranke(wiederholungen, RANKE_WINKEL, RANKE_LAENGE/2**(wiederholungen), RANKE_BREITE)
    else
      puts "Typ nicht bekannt"
    end
  end


  # F-> C0FF-[C1-F+F+F]+[C2+F-F-F]
  # Dabei sind C0,C1,C2 Anweisungen an die Turtle, um die Farbe zu wechseln

  def baum(n, winkel, laenge, breite)
    # TODO
  end

  # F-> C0FF[C1-F++F][C2+F--F]C3++F--F
  # Dabei sind C0-C3 Anweisungen an die Turtle, um die Farbe zu wechseln
  def ranke(n, winkel, laenge, breite)
   # TODO
  end

  def loeschen()
    @turtle.loeschen()
  end
  
end