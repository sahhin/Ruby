# konvergiert gegen 0.25
def g_it(n)
  return 0
end

def g_rek(n)
  return 0
end
def g_rek_sp(n,sp)
  return 0
end


def ln_halbe_it(x,n)
  return 0
end
def ln_halbe_rek(x,n)
  return 0
end

def ln_halbe_rek_sp(x,n,sp)
  return 0
end

def palindrom?(zeichenkette)
  # normalisiere und entferne Leerzeichen
  norm = normalisiere(zeichenkette)
  _palindrom?(norm)
end

def normalisiere(zk)
  zk.downcase().delete(" \\',.?\\-\"\n")
end

def _palindrom?(zeichenkette)
end

def _palindrom_sp?(zeichenkette,sp)
end
