class Knoten

  def initialize(inhalt)
    @inhalt = inhalt
    @nachfolger = nil
  end

  def << (inhalt)
  #TODO
  end

  def each(&b)
  #TODO
  end

  def to_s()
    return @inhalt.to_s()
  end

end