def max_width(ary)
  return 0
end

def deep_count_elems_with_ary(ary)
end

def deep_group_by_type(ary,type_hash= {})
  return {}
end

def deep_reverse(a_hash)
  return {}
end

