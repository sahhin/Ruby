
class Freund

  # TODO

end