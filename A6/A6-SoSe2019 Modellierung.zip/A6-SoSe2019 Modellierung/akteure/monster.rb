
class Monster
  # TODO
end