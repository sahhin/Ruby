require_relative 'gegenstand'
class Tankstelle < Gegenstand

  # TODO
end