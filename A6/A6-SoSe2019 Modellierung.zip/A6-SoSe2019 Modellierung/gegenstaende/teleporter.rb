require_relative "gegenstand"

class Teleporter < Gegenstand

  #TODO

end