require_relative "gegenstand"

class Waffe < Gegenstand

  # TODO
end
