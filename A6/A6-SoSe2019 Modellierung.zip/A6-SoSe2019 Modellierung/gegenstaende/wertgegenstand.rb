class Wertgegenstand < Gegenstand

  # TODO

end
