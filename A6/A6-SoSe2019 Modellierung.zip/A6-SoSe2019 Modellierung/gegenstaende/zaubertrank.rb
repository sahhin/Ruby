require_relative "gegenstand"
class Zaubertrank < Gegenstand

  # TODO
end