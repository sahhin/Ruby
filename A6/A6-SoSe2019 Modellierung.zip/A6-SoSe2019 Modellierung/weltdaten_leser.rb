require_relative 'akteure/freund'
require_relative 'akteure/monster'
require_relative 'gegenstaende/tankstelle'
require_relative 'gegenstaende/teleporter'
require_relative 'gegenstaende/waffe'
require_relative 'gegenstaende/wertgegenstand'
require_relative 'gegenstaende/zaubertrank'

class WeltdatenLeser

  def self.lese_daten(filename)
    objects_and_position = []
    # TODO
    return objects_and_position
  end
end