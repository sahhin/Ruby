class Monster

  # TODO
  def initialize(name,lebenspunkte,effekt)

  end
  # TODO
end