class WeltObjekt  # class oder module das müssen Sie entscheiden Teil der Aufgabe
  attr_reader  :name

  def initialize(name)
    @name = name
  end

  # TODO

  def to_s(kurzform=false)
    if kurzform
      "#{self.class.name[0]}"
    else
      "Ich #{self.class.name} #{@name}"
    end
  end
end