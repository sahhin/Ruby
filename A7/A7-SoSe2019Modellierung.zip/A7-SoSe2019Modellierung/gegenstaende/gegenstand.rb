require_relative '../common/welt_objekt'
class Gegenstand  < WeltObjekt # class oder module das müssen Sie entscheiden Teil der Aufgabe
  attr_reader :gewicht

  def initialize(name, gewicht)
    super(name)
    @gewicht = gewicht
  end

  # TODO

  def to_s(kurzform = false)
    if kurzform
      return "#{super(kurzform)}.#{@gewicht}"
    else
      return "#{super} [#{@gewicht} kg]"
    end
  end

end