
class Teleporter  # class oder module das müssen Sie entscheiden Teil der Aufgabe
   # TODO
  def initialize(name,strecke_in_quadranten)

  end
  # TODO Rest
end