class Waffe  # class oder module das müssen Sie entscheiden Teil der Aufgabe
  # TODO Vererbung
  def initialize(name, gewicht, staerke)
  end
  # TODO Rest
end
