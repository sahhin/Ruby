class Akteur # class oder module das müssen Sie entscheiden Teil der Aufgabe

  # TODO

end