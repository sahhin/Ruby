class Freund

  # TODO
  #
  def initialize(name,lebenspunkte,effekt)

  end

  # TODO
end