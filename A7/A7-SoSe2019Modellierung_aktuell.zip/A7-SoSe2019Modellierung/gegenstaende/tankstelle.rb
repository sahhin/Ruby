class Tankstelle  # class oder module das müssen Sie entscheiden Teil der Aufgabe
  # TODO
  def initialize(name,liter)

  end
  # TODO
end