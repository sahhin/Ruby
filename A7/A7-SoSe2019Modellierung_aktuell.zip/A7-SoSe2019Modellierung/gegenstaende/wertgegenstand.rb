class Wertgegenstand  # class oder module das müssen Sie entscheiden Teil der Aufgabe

  # TODO Vererbung

  def initialize(name,gewicht,wert)
  end

  # TODO

end

class Diamand < Wertgegenstand
  
end