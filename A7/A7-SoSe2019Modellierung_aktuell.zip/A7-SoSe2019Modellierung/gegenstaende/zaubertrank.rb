class Zaubertrank # class oder module das müssen Sie entscheiden Teil der Aufgabe
  # TODO

  def initialize(name, gewicht, lebenspunkte, staerke, positive = true)
  end
end