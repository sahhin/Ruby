# Author::    Birgit Wendholt
# Copyright:: Adaptiert die BlueJ Implementierung (Michael Kölling & David J. Barnes) für Ruby und Tcl-TK

require_relative "./Spiel"
welt = Spiel.instance().welt_anlegen(6,"weltdaten").spielen()
